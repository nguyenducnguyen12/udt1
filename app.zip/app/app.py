import customtkinter as ctk
import os,json,matplotlib,openpyxl,pandas,xlrd,webbrowser,sys,shutil
from PIL import Image, ImageTk
import tkinter.filedialog as filedialog
from tkinter import messagebox
class Pyqm:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = {}
    def compile(self):
        with open("Resouces\\Settinngs\\Langjs\\chosserlang.json", 'r', encoding="UTF-8") as file:
            settings = json.load(file)
        language = settings["language"]
        qm_file = f"Resouces//Language//{language}.qm"

        if not os.path.isfile(qm_file):
            qm_file = "Resouces//Language/VIE.QM"
        with open(qm_file, 'r', encoding="UTF-8") as file:
            lines = file.readlines()
        for line in lines:
            if line.startswith('#'):
                continue
            index = line.find('=')
            if index != -1:
                key = line[:index].strip().lower()
                value = line[index + 1:].strip()
                self.data[key] = value
    def translate(root1, key):
        return root1.data.get(key.lower())
pyqm = Pyqm('Resouces//Language//VIE.QM')
pyqm.compile()
app=ctk.CTk()
app.title(pyqm.translate("Account"))
app.iconbitmap("Resouces\\Image\\ico\\app.ico")
app.geometry("900x500")
root1=ctk.CTk()
root1.geometry("900x500")
root1.iconbitmap("Resouces\\Image\\ico\\app.ico")
root1.title(pyqm.translate("MAIN_APP_NAME_TITLE"))
root1.configure(fg_color="#F9FBE7")
app.configure(fg_color="#F9FBE7")
app.resizable(False,False)
root1.resizable(False,False)
def wr1():
    app.withdraw()
    root1.deiconify()
def wr2():
    app.deiconify()
    root1.withdraw()
def exit_app():
    app.destroy()
    root1.destroy()
app.protocol("WM_DELETE_WINDOW", exit_app)
root1.protocol("WM_DELETE_WINDOW", exit_app)
#color_and_chooser
with open("Resouces\\Settinngs\\Colorjs\\Button.json") as bt:
    but=json.load(bt)
with open("Resouces\\Settinngs\\Colorjs\\color.json",'r') as bt:
    color=json.load(bt)
frame1_color=color[1]["Frame"]["FrameControl"]
frame2_color=color[1]["Frame"]["Frame_Broad"]
button_color=color[0]["Button"]["Button_color"]
button_hover_color=color[0]["Button"]["button_hover_color"]
border_color=color[0]["Button"]["border_color"]
dropdown_fg_color=color[0]["Button"]["dropdown_fg_color"]
with open("Resouces\\Settinngs\\Colorjs\\Button.json",'r') as bt:
    bt1=json.load(bt)
button_fg=bt1["button_fg"]
hover_color=bt1["hover_color"]
#frame
frame1=ctk.CTkFrame(app,fg_color=frame1_color,width=100,height=1000)
frame1.place(x=0,y=0)
frame3=ctk.CTkFrame(root1,fg_color=frame1_color,width=100,height=1000)
frame3.place(x=0,y=0)
"""taskbar"""
button1_taskbar1=ctk.CTkButton(frame1,text=pyqm.translate("Account"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr2)
button1_taskbar1.place(x=0,y=20)
button1_taskbar2=ctk.CTkButton(frame1,text=pyqm.translate("Management_button"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white", command=wr1)
button1_taskbar2.place(x=0,y=50)
button1_taskbar3=ctk.CTkButton(frame1,text=pyqm.translate('settings'),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white")
button1_taskbar3.place(x=0,y=80)
button2_taskbar1=ctk.CTkButton(frame3,text=pyqm.translate("Account"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr2)
button2_taskbar1.place(x=0,y=20)
button2_taskbar2=ctk.CTkButton(frame3,text=pyqm.translate("Management_button"),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white",command=wr1)
button2_taskbar2.place(x=0,y=50)
button2_taskbar3=ctk.CTkButton(frame3,text=pyqm.translate('settings'),fg_color=button_fg,hover_color=hover_color,width=15,text_color="white")
button2_taskbar3.place(x=0,y=80)
#taikhoan
label_name=ctk.CTkLabel(app,text=pyqm.translate("Account"),fg_color="#F9FBE7",font=("Arial",16))
label_name.pack()
with open("Database\\data\\save.json",'r',encoding="UTF-8") as dt:
    data=json.load(dt)
name_pl=data["name"]
age_pl=data["age"]
place_pl=data["place"]
class_pl= data["class"]
school_pl=data["school"]
my_image = ctk.CTkImage( Image.open("Resouces\\Image\\png\\picture.png"),size=(130, 130))
img=ctk.CTkButton(app,image=my_image,text="",fg_color="#F9FBE7",hover_color="#F9FBE7",command=lambda:messagebox.showinfo("ct",'cập nhật')).pack(pady=2)
ifmt=ctk.CTkLabel(app,text=pyqm.translate("info"))
ifmt.pack()
fr=ctk.CTkFrame(app,width=700,height=300,fg_color="#99ff99")
fr.place(x=140,y=210)
name=ctk.CTkLabel(fr,text=pyqm.translate("name"),font=("arial",15))
name.place(x=10,y=20)
entry_name=ctk.CTkEntry(fr,placeholder_text=name_pl,placeholder_text_color="black")
entry_name.place(x=90,y=20)
age=ctk.CTkLabel(fr,text=pyqm.translate("age"),font=("arial",15))
age.place(x=10,y=90)
entry_age=ctk.CTkEntry(fr,placeholder_text=age_pl,placeholder_text_color="black")
entry_age.place(x=90,y=90)
place=ctk.CTkLabel(fr,text=pyqm.translate("place"),font=("ARIAL",15))
place.place(x=10,y=160)
entry_place=ctk.CTkEntry(fr,placeholder_text=place_pl,placeholder_text_color="black")
entry_place.place(x=90,y=160)
lop=ctk.CTkLabel(fr,text=pyqm.translate("class"),font=("Arial",15))
lop.place(x=390,y=20)
entry_lop=ctk.CTkEntry(fr,placeholder_text=class_pl,placeholder_text_color="black")
entry_lop.place(x=460,y=20)
school=ctk.CTkLabel(fr,text=pyqm.translate("school"),font=("arial",15))
school.place(x=390,y=90)
entry_school=ctk.CTkEntry(fr,placeholder_text=school_pl,placeholder_text_color="black")
entry_school.place(x=460,y=90)
birthday=ctk.CTkLabel(fr,text=pyqm.translate("birth"),font=("arial",13))
birthday.place(x=390,y=160)
app.mainloop()